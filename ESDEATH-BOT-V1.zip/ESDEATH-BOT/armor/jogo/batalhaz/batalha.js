// #Game Feita 100% Por Mim ©Blackzin!!

 var person =['Vegeta','Kakaroto','Gohan','Broly','Freeza','Majin Boo','Cell','Androide 17','Piccolo','Mestre Kame','Kuririn','Caos','Yamcha','Mister Satan','Nappa','Gogeta','Vegetto','Jiren']
 
 var atk = ['Volley Blas','DodonPa','Ki Blast','Masenko','Kamehameha','Galick Gun','Taioken','Genkidama','Super Dragon Fist','Big Bang Attack','Escudo de Ki','Spirit Sword','Final Kamehameha','Big Bang Kamehameha','Stardust Breaker','Punisher Drive','Masenko','Mafuba','Makankosappo','Mão Demoníaca','Forma Mística','Death Saucer','Death Beam']
 
 var atki = ['Volley Blas','DodonPa','Ki Blast','Masenko','Kamehameha','Galick Gun','Taioken','Genkidama','Super Dragon Fist','Big Bang Attack','Escudo de Ki','Spirit Sword','Final Kamehameha','Big Bang Kamehameha','Stardust Breaker','Punisher Drive','Masenko','Mafuba','Makankosappo','Mão Demoníaca','Forma Mística','Death Saucer','Death Beam']

var titul =['*❰ 👊🏻 BATALHA Z 👊🏻 ❱*\n\nEssa Batalha é decisiva🤼‍♂️','*❰ 👊🏻 BATALHA Z 👊🏻 ❱*\n\nTa dificil acompanhar esse ritmo','*❰ 👊🏻 BATALHA Z 👊🏻 ❱*\n\nEssa Luta ta bem Disputada em..🥵','*❰ 👊🏻 BATALHA Z 👊🏻 ❱*\n\nQuem Será o Vitorioso😬😬','*❰ 👊🏻 BATALHA Z 👊🏻 ❱*\n\n Ouou Q luta epica 😳🍃','*❰ 👊🏻 BATALHA Z 👊🏻 ❱*\n\nMas Que Batalha é essa🙈🙈']

var ki = Math.floor(Math.random() * 50) + 1 

var kih = Math.floor(Math.random() * 50) + 1 

module.exports = { person, atk, atki, titul, ki, kih }