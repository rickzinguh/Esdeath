
SÓ DEVO LEMBRAR QUE O TERMUX DA PLAY STORE NÃO PRESTA, ENTÃO INSTALE O 118 POR LÁ 

> https://www.apkmirror.com/apk/fredrik-fornwall/termux-github-version/termux-github-version-0-119-1-release/termux-github-version-0-119-1-android-apk-download/download/?key=2407bb2fc64ebc715c619e0d14b4b05e9fb340be 


Comandos Básicos do termux, nescessario para inicialização do bot:


-_1 COMANDO :

termux-change-repo 

Confirma, marca a terceira caixinha e confirma e prossegue > 

-_2 COMANDO :

apt-get upgrade

Vai precisar digitar y e confirmar toda vez que pedir.

-_3 COMANDO :

apt-get update

Vai precisar digitar y e confirmar toda vez que pedir.

-_4 Comando :

pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install git -y

-_5 COMANDO :

termux-setup-storage


E permite.

ÚLTIMO  CMD :

npm i -g npm@6 && npm i heroku -g

