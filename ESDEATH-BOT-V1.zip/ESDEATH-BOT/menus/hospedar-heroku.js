const hospedar = (prefix) => {
return `

COMANDOS DO HEROKU ATUALIZADO. Lista e arquivo feita pelo Lotus


tenha uma conta no site heroku
https://id.heroku.com/signup/login


1 COMANDO


npm i -g npm@6 && npm i heroku -g


------------------------------




2 COMANDO.


termux-setup-storage



------------------------------


 3 COMANDO...


cd /sdcard/PASTA-DO-BOT


         Ou


cd /sdcard/download/PASTA-DO-BOT


------------------------------


4 COMANDO..


sh hospedar.sh


e siga os passos

------------------------------




PARA ATUALIZAR BASTA BOTAR.


cd /sdcard/PASTA-DO-BOT




sh heroku.sh




     FIM!!



------------------------------


`
}

exports.hospedar = hospedar
