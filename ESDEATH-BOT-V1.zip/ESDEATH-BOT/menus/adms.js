const adms = (prefix) => { 
 
// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 

	return `
╭━━━━━◉                                       ◉━━━━━╮
    ╔┉✼┉═༺◈✼❄️✼◈༻═┉✼┉╗   
    ║       *👮‍♀️𝐌𝐄𝐍𝐔 𝐀𝐃𝐌👮‍♂️*                 
    ╚┉✼┉═༺◈✼❄️✼◈༻═┉✼┉╝   
╰━━━━━◉                                      ◉━━━━━╯
	​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​​
	
▢ ⌁ᴍᴇɴᴜ ᴀᴅᴍ,ғᴇɪᴛᴏ ᴘᴀʀᴀ ᴀᴘᴇɴᴀs ᴀᴅᴍɪɴɪsᴛʀᴀᴅᴏʀ ᴅᴏ ɢʀᴜᴘᴏ⌁ ▢ 
╭═══════◉
┆      ╔┉✼┉═༺◈✼❄️✼◈༻═┉✼┉╗
┆      ║
┆      ║✼❄ ${prefix}kick [@] (pra-remover) 
┆      ║✼❄ ${prefix}ban (responder-mensagem)
┆      ║✼❄ ${prefix}ban2 (banir com tempo)
┆      ║✼❄ ${prefix}promover [@] (promover adm)
┆      ║✼❄ ${prefix}rebaixar [@] (rebaixar adm)
┆      ║✼❄ ${prefix}totag (menciona-algo)
┆      ║✼❄ ${prefix}grupo f/a
┆      ║✼❄ ${prefix}nomegp (Nome)
┆      ║✼❄ ${prefix}sorteio
┆      ║✼❄ ${prefix}sorteionumero
┆      ║✼❄ ${prefix}status
┆      ║✼❄ ${prefix}onlines
┆      ║✼❄ ${prefix}admins
┆      ║✼❄ ${prefix}destrava
┆      ║✼❄ ${prefix}destrava2
┆      ║✼❄ ${prefix}digt
┆      ║✼❄️ ${prefix}Grupos (Grupos Aleatórios)
┆      ║✼❄ ${prefix}regraspp
┆      ║✼❄ ${prefix}apresentar
┆      ║✼❄ ${prefix}limpar (texto-invisível-gp)
┆      ║✼❄ ${prefix}atividades (DO-GRUPO)
┆      ║✼❄ ${prefix}linkgp
┆      ║✼❄ ${prefix}infogp
┆      ║✼❄ ${prefix}listafake
┆      ║✼❄ ${prefix}listanegra (559numero)
┆      ║✼❄ ${prefix}tirardalista
┆      ║✼❄ ${prefix}listaban
┆      ║✼❄ ${prefix}descriçãogp
┆      ║✼❄ ${prefix}grupoinfo
┆      ║✼❄ ${prefix}hidetag (txt) (marcação)
┆      ║✼❄ ${prefix}marcar (marca tds do gp)
┆      ║✼❄ ${prefix}marcar2 (wa.me/)
┆      ║✼❄ ${prefix}autoresposta 1 / 0
┆      ║✼❄ ${prefix}modo+18 1 / 0
┆      ║✼❄ ${prefix}anagrama 1 / 0
┆      ║✼❄ ${prefix}Autofigu 1 / 0
┆      ║✼❄ ${prefix}Antipalavra 1 / 0
┆      ║✼❄ ${prefix}antidocumento 1 / 0  
┆      ║✼❄ ${prefix}antiloc 1 / 0  
┆      ║✼❄ ${prefix}anticontato 1 / 0  
┆      ║✼❄ ${prefix}antinotas 1 / 0
┆      ║✼❄ ${prefix}antilink 1 / 0
┆      ║✼❄ ${prefix}antilinkgp 1 / 0
┆      ║✼❄ ${prefix}antilinkhard 1 / 0
┆      ║✼❄ ${prefix}Antiviewonce 1 / 0
┆      ║✼❄ ${prefix}antiporno 1 / 0
┆      ║✼❄ ${prefix}antifake 1 / 0
┆      ║✼❄ ${prefix}antimarc 1 / 0
┆      ║✼❄ ${prefix}bemvindo 1 / 0
┆      ║✼❄ ${prefix}bemvindo2 1 / 0
┆      ║✼❄ ${prefix}antiimg 1 / 0
┆      ║✼❄ ${prefix}antiaudio 1 / 0
┆      ║✼❄ ${prefix}antivideo 1 / 0
┆      ║✼❄ ${prefix}antisticker 1 / 0
┆      ║✼❄ ${prefix}limitecaracteres  1 / 0
┆      ║✼❄ ${prefix}modobrincadeira  1 / 0
┆      ║✼❄ ${prefix}leveling 1 / 0  
┆      ║✼❄ ${prefix}simih 1 / 0
┆      ║✼❄ ${prefix}simih2 1 / 0
┆      ║✼❄ ${prefix}legendabv (com foto)
┆      ║✼❄ ${prefix}legendabv2 (sem foto)
┆      ║✼❄ ${prefix}legendasaiu (com foto)
┆      ║✼❄ ${prefix}legendasaiu2 (sem foto)
┆      ║✼❄ ${prefix}fotogp (Marca)
┆      ║✼❄ ${prefix}descgp (TXT)
┆      ║✼❄ ${prefix}Criartabela (ESCREVA-ALGO)
┆      ║✼❄ ${prefix}nomegp (Nome)
┆      ║✼❄ ${prefix}reviver (MARCAR)
┆      ║✼❄ ${prefix}add (número)
┆      ║✼❄ ${prefix}resetarttt
┆      ║✼❄ ${prefix}resetarvelha
┆      ║
┆      ╚┉✼┉══༺◈✼❄️✼◈༻══┉✼┉╝
╰═══════◉
`
}

exports.adms = adms

// NÃO APAGUE ESSE ${prefix}, não coloque nada ${dentro assim} ISSO SÃO DEFINIÇÕES QUE ESTÁ PUXANDO DO settings.json, da pasta dono, só pode altera a base de tudo, menos as definições, só se quiser apagar a definição completa. 