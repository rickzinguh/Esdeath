const cmd_termux = (prefix) => {
return `
SÓ DEVO LEMBRAR QUE O TERMUX DA PLAY STORE NÃO PRESTA, ENTÃO INSTALE O 118 POR LÁ 

> aleatoryapi.herokuapp.com 


Comandos Básicos do termux, nescessario para inicialização do bot:


- _1 COMANDO :


termux-change-repo

APERTA OK

_-_-_       _-_-_.        _-_-_

MARCA A TERCEIRA CAIXINHA E APERTA OK.

_-_-_      _-_-_-        _-_-_-


_2 COMANDO


pkg upgrade -y 


ASSISTA O VIDEO, ALGUMAS VEZES QUANDO PAUSAR É NESCESSARIO DA ENTER, VAI PAUSAR A AÇÃO E VAI APARECER [default=N] ?

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

_3 COMANDO 


pkg update -y


_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

_4 COMANDO


termux-setup-storage

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

_5 COMANDO 


pkg install nodejs -y

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

_6 COMANDO 


pkg install nodejs-lts -y

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-

_7 COMANDO 


pkg install git -y

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-


_8 COMANDO 


pkg install ffmpeg -y

_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-


_9 COMANDO NESCESSARIO PRA O HEROKU


npm i -g npm@6 && npm i heroku -g


_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-_-


PRONTO, BOA SORTE... 


`
}

exports.cmd_termux = cmd_termux
